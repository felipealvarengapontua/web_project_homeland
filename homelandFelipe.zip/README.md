# Tripleten web_project_homeland

Uma verdadeira volta ao mundo , conhecendo varios lugares através dessa pagina intuitiva e responsiva
criada usando HTML e CSS .
